package com.alpiq.maven.plugin.mojo;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import com.alpiq.maven.plugin.service.GitChangedFilesService;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Mojo(name = "create-postman", aggregator = true)
public class CreatePostmanMojo extends AbstractMojo {
    @Parameter(property = "inputDir", defaultValue = "${project.basedir}/src/main/java")
    private String inputDir;

    @Parameter(property = "postmanFilename", defaultValue = "${project.build.directory}/generated-postman/alpiq-scripts/alpiq-scripts.json")
    private String postmanFilename;

    /**
     * Root of the Git working tree or module containing the scripts.
     * Use this when the POM is in one module and the Java scripts are in another module.
     */
    @Parameter(property = "scriptsModulePath", defaultValue = "${project.basedir}")
    private File scriptsModulePath;

    /**
     * Generate alpiq-scripts.json only from Java files changed in the last X days.
     * The detection is based on Git logs, not filesystem dates.
     */
    @Parameter(property = "modifiedLastDays")
    private Integer modifiedLastDays;

    /**
     * Optional Git tag/reference used as a stronger alternative to modifiedLastDays.
     * Example: -DgitSinceTag=26.05.00
     */
    @Parameter(property = "gitSinceTag")
    private String gitSinceTag;

    /**
     * Optional Git branch/reference used as an alternative to modifiedLastDays.
     * Example: -DgitSinceBranch=release/26.06
     */
    @Parameter(property = "gitSinceBranch")
    private String gitSinceBranch;

    @Override
    public void execute() throws MojoExecutionException {
        File postmanFile = new File(postmanFilename);
        getLog().info("Scanning " + inputDir + " and writing Postman collection to " + postmanFile.getAbsolutePath());
        File parent = postmanFile.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }

        String postmanTemplate = readTemplate();
        int scriptStart = postmanTemplate.indexOf("\"---startScript---\"");
        int scriptEnd = postmanTemplate.indexOf("\"---endScript---\"");
        if (scriptStart < 0 || scriptEnd < 0) {
            throw new MojoExecutionException("Invalid Postman.collection.template.json: missing script markers");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(postmanFile, false))) {
            String header = postmanTemplate.substring(0, scriptStart);
            String section = postmanTemplate.substring(scriptStart + "\"---startScript---\"".length(), scriptEnd);
            String footer = postmanTemplate.substring(scriptEnd + "\"---endScript---\"".length());
            writer.write(header);

            List<File> files = resolveJavaFiles();
            int count = 0;
            for (File file : files) {
                String content = FileUtils.readFileToString(file, "UTF-8");
                String classname = getFullClassname(content);
                if (classname == null || classname.endsWith(".null")) {
                    continue;
                }
                String rendered = section
                        .replace("<---scriptClassName--->", classname)
                        .replace("<---simpleScriptClassName--->", classname.substring(classname.lastIndexOf('.') + 1))
                        .replace("<---scriptContent--->", StringEscapeUtils.escapeJson(content).replaceAll("(\\r|\\n|\\r\\n)+", "\\\\n"));
                if (count > 0) {
                    writer.write(",");
                }
                writer.write(rendered);
                count++;
            }
            writer.newLine();
            writer.write(footer);
            getLog().info("Generated " + count + " scripts in " + postmanFile.getAbsolutePath());
        } catch (Exception e) {
            throw new MojoExecutionException("Failed to produce Postman file " + postmanFile.getAbsolutePath(), e);
        }
    }

    private List<File> resolveJavaFiles() throws MojoExecutionException {
        File sources = new File(inputDir).getAbsoluteFile();
        if (!sources.exists() || !sources.isDirectory()) {
            throw new MojoExecutionException("inputDir does not exist or is not a directory: " + sources);
        }

        GitChangedFilesService gitChangedFilesService = new GitChangedFilesService(getLog());
        if (gitChangedFilesService.isGitFilterConfigured(modifiedLastDays, gitSinceTag, gitSinceBranch)) {
            List<File> changedFiles = gitChangedFilesService.findChangedJavaFiles(
                    scriptsModulePath,
                    sources,
                    modifiedLastDays,
                    gitSinceTag,
                    gitSinceBranch);
            getLog().info("Git changed Java files selected for Postman generation: " + changedFiles.size());
            return changedFiles.stream()
                    .sorted(Comparator.comparing(File::getAbsolutePath))
                    .collect(Collectors.toList());
        }

        getLog().info("No Git filter configured. Scanning all Java files under " + sources.getAbsolutePath());
        return FileUtils.listFiles(sources, new String[]{"java"}, true)
                .stream()
                .sorted(Comparator.comparing(File::getAbsolutePath))
                .collect(Collectors.toList());
    }

    private String readTemplate() throws MojoExecutionException {
        URL template = getClass().getClassLoader().getResource("Postman.collection.template.json");
        if (template == null) {
            throw new MojoExecutionException("Postman.collection.template.json not found in plugin resources");
        }
        try (Scanner scanner = new Scanner(template.openStream(), "UTF-8")) {
            scanner.useDelimiter("\\Z");
            return scanner.next();
        } catch (Exception e) {
            throw new MojoExecutionException("Failed to read Postman template file", e);
        }
    }

    private String getPackageName(String src) {
        return patternMatcher("package (.*?);", src);
    }

    private String getClassName(String src) {
        String className = patternMatcher("public class (.*?)( extends| implements|\\s*\\{)", src);
        return className != null ? className.trim() : null;
    }

    private String getFullClassname(String script) {
        String packageName = getPackageName(script);
        String className = getClassName(script);
        if (className == null) {
            return null;
        }
        return (packageName != null ? packageName.trim() + "." : "") + className;
    }

    private static String patternMatcher(String regex, String text) {
        Matcher matcher = Pattern.compile(regex).matcher(text);
        return matcher.find() ? matcher.group(1) : null;
    }
}
