package com.alpiq.maven.plugin.mojo;

import com.alpiq.maven.plugin.model.ReleaseSummary;
import com.alpiq.maven.plugin.service.MergePostmanService;
import com.alpiq.maven.plugin.service.MergeSqlService;
import com.alpiq.maven.plugin.service.ReleaseValidator;
import com.alpiq.maven.plugin.util.FileSupport;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import java.io.File;

@Mojo(name = "build-release", aggregator = true)
public class BuildReleaseMojo extends AbstractMojo {
    private static final String[] TARGET_ENVIRONMENTS = {"B2B", "B2C"};

    @Parameter(property = "releaseVersion", required = true)
    private String releaseVersion;

    @Parameter(property = "releaseNotesDir", defaultValue = "${project.basedir}/release-notes")
    private File releaseNotesDir;

    @Parameter(property = "outputDirectory", defaultValue = "${project.build.directory}/releases")
    private File outputDirectory;

    @Parameter(property = "generatedScriptsFile", defaultValue = "${project.build.directory}/generated-postman/alpiq-scripts/alpiq-scripts.json")
    private File generatedScriptsFile;

    @Parameter(property = "skipGeneratedScripts", defaultValue = "false")
    private boolean skipGeneratedScripts;

    @Override
    public void execute() throws MojoExecutionException {
        try {
            File releaseVersionDir = new File(releaseNotesDir, releaseVersion);
            new ReleaseValidator().validateVersionDirectory(releaseVersionDir);
            File outputVersionDir = new File(outputDirectory, releaseVersion);
            FileSupport.ensureDirectory(outputVersionDir);

            MergePostmanService postmanService = new MergePostmanService();
            MergeSqlService sqlService = new MergeSqlService();
            ReleaseSummary summary = new ReleaseSummary(releaseVersion, outputVersionDir.getAbsolutePath());

            for (String environment : TARGET_ENVIRONMENTS) {
                ReleaseSummary.EnvSummary envSummary = summary.environment(environment);
                File envOutput = new File(outputVersionDir, environment);

                envSummary.bothPostmanStruct = countJson(new File(new File(releaseVersionDir, "BOTH"), "postman-struct"));
                envSummary.envPostmanStruct = countJson(new File(new File(releaseVersionDir, environment), "postman-struct"));
                postmanService.merge(releaseVersionDir, environment, "postman-struct",
                        new File(envOutput, "postman-struct/alpiq-postman-struct.json"),
                        "Alpiq " + releaseVersion + " " + environment + " - Postman Struct");

                envSummary.bothPostmanJobs = countJson(new File(new File(releaseVersionDir, "BOTH"), "postman-jobs"));
                envSummary.envPostmanJobs = countJson(new File(new File(releaseVersionDir, environment), "postman-jobs"));
                postmanService.merge(releaseVersionDir, environment, "postman-jobs",
                        new File(envOutput, "postman-jobs/alpiq-postman-jobs.json"),
                        "Alpiq " + releaseVersion + " " + environment + " - Postman Jobs");

                if (!skipGeneratedScripts && generatedScriptsFile.exists()) {
                    FileSupport.copyFile(generatedScriptsFile, new File(envOutput, "alpiq-scripts/alpiq-scripts.json"));
                    envSummary.scriptsCopied = true;
                } else {
                    envSummary.scriptsCopied = false;
                    getLog().warn("Generated scripts file not copied. Expected: " + generatedScriptsFile.getAbsolutePath());
                }

                envSummary.sqlStructFiles = sqlService.merge(releaseVersionDir, environment, "sql-struct",
                        new File(envOutput, "sql-struct/alpiq-struct.sql"));
                envSummary.sqlDataFiles = sqlService.merge(releaseVersionDir, environment, "sql-data",
                        new File(envOutput, "sql-data/alpiq-data.sql"));
            }
            summary.print(getLog());
        } catch (Exception e) {
            if (e instanceof MojoExecutionException) {
                throw (MojoExecutionException) e;
            }
            throw new MojoExecutionException("Failed to build Alpiq release", e);
        }
    }

    private int countJson(File directory) throws Exception {
        return FileSupport.listFiles(directory, ".json").size();
    }
}
