package com.alpiq.maven.plugin.model;

import org.apache.maven.plugin.logging.Log;

import java.util.LinkedHashMap;
import java.util.Map;

public class ReleaseSummary {
    public static class EnvSummary {
        public int bothPostmanStruct;
        public int envPostmanStruct;
        public int bothPostmanJobs;
        public int envPostmanJobs;
        public int sqlStructFiles;
        public int sqlDataFiles;
        public boolean scriptsCopied;
    }

    private final String version;
    private final String outputPath;
    private final long startTimeMillis;
    private final Map<String, EnvSummary> environments = new LinkedHashMap<>();

    public ReleaseSummary(String version, String outputPath) {
        this.version = version;
        this.outputPath = outputPath;
        this.startTimeMillis = System.currentTimeMillis();
    }

    public EnvSummary environment(String name) {
        EnvSummary summary = environments.get(name);
        if (summary == null) {
            summary = new EnvSummary();
            environments.put(name, summary);
        }
        return summary;
    }

    public void print(Log log) {
        double elapsed = (System.currentTimeMillis() - startTimeMillis) / 1000.0;
        log.info("=========================================================");
        log.info("        ALPIQ RELEASE PACKAGE");
        log.info("=========================================================");
        log.info("");
        log.info("Release Version : " + version);
        log.info("");
        for (Map.Entry<String, EnvSummary> entry : environments.entrySet()) {
            String env = entry.getKey();
            EnvSummary s = entry.getValue();
            log.info("---------------------------------------------------------");
            log.info("Building " + env);
            log.info("---------------------------------------------------------");
            log.info("OK Merge BOTH/postman-struct : " + s.bothPostmanStruct + " collections");
            log.info("OK Merge " + env + "/postman-struct  : " + s.envPostmanStruct + " collections");
            log.info("OK Generated                 : postman-struct/alpiq-postman-struct.json");
            log.info("");
            log.info("OK Merge BOTH/postman-jobs   : " + s.bothPostmanJobs + " collections");
            log.info("OK Merge " + env + "/postman-jobs    : " + s.envPostmanJobs + " collections");
            log.info("OK Generated                 : postman-jobs/alpiq-postman-jobs.json");
            log.info("");
            log.info((s.scriptsCopied ? "OK" : "WARN") + " Copied generated scripts  : alpiq-scripts/alpiq-scripts.json");
            log.info("");
            log.info("OK Merge SQL Structure       : " + s.sqlStructFiles + " files");
            log.info("OK Generated                 : sql-struct/alpiq-struct.sql");
            log.info("");
            log.info("OK Merge SQL Data            : " + s.sqlDataFiles + " files");
            log.info("OK Generated                 : sql-data/alpiq-data.sql");
            log.info("");
        }
        log.info("=========================================================");
        log.info("Release successfully generated");
        log.info("Output: " + outputPath);
        log.info("Packages generated: " + environments.keySet());
        log.info(String.format("Elapsed time : %.1f s", elapsed));
        log.info("=========================================================");
    }
}
