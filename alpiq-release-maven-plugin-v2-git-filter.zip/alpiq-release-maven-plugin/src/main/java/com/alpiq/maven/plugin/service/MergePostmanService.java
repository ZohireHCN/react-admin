package com.alpiq.maven.plugin.service;

import com.alpiq.maven.plugin.util.FileSupport;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MergePostmanService {
    private final ObjectMapper mapper = new ObjectMapper();

    public int merge(File releaseVersionDir, String environment, String folderName, File outputFile, String collectionName) throws IOException {
        List<File> files = new ArrayList<>();
        files.addAll(FileSupport.listFiles(new File(new File(releaseVersionDir, "BOTH"), folderName), ".json"));
        files.addAll(FileSupport.listFiles(new File(new File(releaseVersionDir, environment), folderName), ".json"));

        ObjectNode root = mapper.createObjectNode();
        ObjectNode info = root.putObject("info");
        info.put("_postman_id", UUID.randomUUID().toString());
        info.put("name", collectionName);
        info.put("schema", "https://schema.getpostman.com/json/collection/v2.1.0/collection.json");
        ArrayNode items = root.putArray("item");

        for (File file : files) {
            JsonNode source = mapper.readTree(file);
            JsonNode sourceItems = source.get("item");
            String relative = releaseVersionDir.toPath().relativize(file.toPath()).toString().replace('\\', '/');
            ObjectNode folder = mapper.createObjectNode();
            folder.put("name", relative);
            ArrayNode folderItems = folder.putArray("item");
            if (sourceItems != null && sourceItems.isArray()) {
                for (JsonNode item : sourceItems) {
                    folderItems.add(item);
                }
            } else {
                folderItems.add(source);
            }
            items.add(folder);
        }

        FileSupport.writeUtf8(outputFile, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(root));
        return files.size();
    }
}
