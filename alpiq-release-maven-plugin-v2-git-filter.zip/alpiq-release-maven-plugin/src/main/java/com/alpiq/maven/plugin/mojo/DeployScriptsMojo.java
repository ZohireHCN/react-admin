package com.alpiq.maven.plugin.mojo;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

@Mojo(name = "deploy-scripts", aggregator = true)
public class DeployScriptsMojo extends AbstractMojo {
    @Parameter(property = "modifiedLastDays", defaultValue = "0")
    private int modifiedLastDays;

    @Override
    public void execute() throws MojoExecutionException {
        getLog().info("deploy-scripts placeholder. modifiedLastDays=" + modifiedLastDays);
        getLog().info("Implement REST deployment here if you want the plugin to push scripts directly to Alpiq/OpenCell.");
    }
}
