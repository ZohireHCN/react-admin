package com.alpiq.maven.plugin.util;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class FileSupport {
    private FileSupport() {}

    public static void ensureDirectory(File directory) throws IOException {
        if (!directory.exists()) {
            Files.createDirectories(directory.toPath());
        }
    }

    public static List<File> listFiles(File directory, String extension) throws IOException {
        if (directory == null || !directory.exists() || !directory.isDirectory()) {
            return new ArrayList<>();
        }
        try (Stream<Path> stream = Files.walk(directory.toPath())) {
            return stream
                    .filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .filter(file -> file.getName().toLowerCase().endsWith(extension.toLowerCase()))
                    .sorted(Comparator.comparing(File::getAbsolutePath))
                    .collect(Collectors.toList());
        }
    }

    public static String readUtf8(File file) throws IOException {
        return new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
    }

    public static void writeUtf8(File file, String content) throws IOException {
        ensureDirectory(file.getParentFile());
        Files.write(file.toPath(), content.getBytes(StandardCharsets.UTF_8));
    }

    public static void copyFile(File source, File destination) throws IOException {
        ensureDirectory(destination.getParentFile());
        Files.copy(source.toPath(), destination.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }
}
