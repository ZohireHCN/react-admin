package com.alpiq.maven.plugin.service;

import org.apache.maven.plugin.MojoExecutionException;

import java.io.File;

public class ReleaseValidator {
    public void validateVersionDirectory(File releaseVersionDir) throws MojoExecutionException {
        if (!releaseVersionDir.exists() || !releaseVersionDir.isDirectory()) {
            throw new MojoExecutionException("Release directory not found: " + releaseVersionDir.getAbsolutePath());
        }
        requireDirectory(releaseVersionDir, "BOTH");
        requireDirectory(releaseVersionDir, "B2B");
        requireDirectory(releaseVersionDir, "B2C");
    }

    private void requireDirectory(File parent, String name) throws MojoExecutionException {
        File dir = new File(parent, name);
        if (!dir.exists() || !dir.isDirectory()) {
            throw new MojoExecutionException("Required directory missing: " + dir.getAbsolutePath());
        }
    }
}
