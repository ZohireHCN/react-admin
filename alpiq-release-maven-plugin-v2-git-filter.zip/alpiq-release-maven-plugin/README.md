# alpiq-release-maven-plugin

Plugin Maven interne pour générer les collections Postman Alpiq et construire une release fonctionnelle B2B/B2C à partir d'un dossier `release-notes`.

Le plugin garde une convention simple :

```text
BOTH + B2B -> package B2B
BOTH + B2C -> package B2C
```

`BOTH` contient les éléments communs aux deux environnements. `B2B` et `B2C` contiennent uniquement les éléments spécifiques.

---

## Goals disponibles

```bash
mvn alpiq:create-postman
mvn alpiq:build-release -DreleaseVersion=26.06.01
mvn alpiq:deploy-scripts -DmodifiedLastDays=7
```

### `alpiq:create-postman`

Scanne les classes Java et génère la collection Postman des scripts Java.

Sortie par défaut :

```text
target/generated-postman/
└── alpiq-scripts/
    └── alpiq-scripts.json
```

Paramètres utiles :

```bash
-DinputDir=src/main/java
-DpostmanFilename=target/generated-postman/alpiq-scripts/alpiq-scripts.json
-DscriptsModulePath=../module-scripts
-DmodifiedLastDays=7
-DgitSinceTag=26.05.00
-DgitSinceBranch=release/26.06
```

Par défaut, sans filtre Git, `create-postman` scanne tous les fichiers Java sous `inputDir`.

Avec `modifiedLastDays`, le plugin ne se base pas sur la date système des fichiers. Il interroge Git avec une logique équivalente à :

```bash
git log --since="7 days ago" --name-only --pretty=format: --
```

Puis il garde uniquement les fichiers `.java` présents dans `inputDir`.

Priorité des filtres Git :

```text
1. gitSinceTag
2. gitSinceBranch
3. modifiedLastDays
4. scan complet si aucun filtre n'est renseigné
```

### `alpiq:build-release`

Construit la release complète à partir de :

```text
release-notes/<releaseVersion>/
```

Il génère deux packages : `B2B` et `B2C`.

### `alpiq:deploy-scripts`

Goal conservé pour l'évolution du plugin. Il reçoit déjà :

```bash
-DmodifiedLastDays=7
```

La logique de déploiement REST peut être ajoutée ensuite.

---

## Workflow complet par ordre

### 1. Compiler le projet

```bash
mvn clean install
```

### 2. Générer la collection des scripts Java

Génération complète :

```bash
mvn alpiq:create-postman
```

Génération uniquement des scripts Java modifiés dans les 7 derniers jours selon Git :

```bash
mvn alpiq:create-postman \
  -DmodifiedLastDays=7
```

Si le POM est dans un module et les scripts Java dans un autre module :

```bash
mvn alpiq:create-postman \
  -DscriptsModulePath=../module-scripts \
  -DinputDir=../module-scripts/src/main/java \
  -DmodifiedLastDays=7
```

Pour une release, il est encore plus fiable de travailler par tag ou branche Git :

```bash
mvn alpiq:create-postman \
  -DscriptsModulePath=../module-scripts \
  -DinputDir=../module-scripts/src/main/java \
  -DgitSinceTag=26.05.00
```

ou :

```bash
mvn alpiq:create-postman \
  -DscriptsModulePath=../module-scripts \
  -DinputDir=../module-scripts/src/main/java \
  -DgitSinceBranch=release/26.06
```

Cette commande produit :

```text
target/generated-postman/alpiq-scripts/alpiq-scripts.json
```

### 3. Préparer les release notes

Créer la structure suivante dans le module où la commande sera exécutée :

```text
release-notes/
└── 26.06.01/
    ├── BOTH/
    │   ├── postman-struct/
    │   ├── postman-jobs/
    │   ├── sql-struct/
    │   └── sql-data/
    │
    ├── B2B/
    │   ├── postman-struct/
    │   ├── postman-jobs/
    │   ├── sql-struct/
    │   └── sql-data/
    │
    └── B2C/
        ├── postman-struct/
        ├── postman-jobs/
        ├── sql-struct/
        └── sql-data/
```

Important : il n'y a pas de dossier `postman-scripts` dans `BOTH`, `B2B` ou `B2C`.
Le fichier `alpiq-scripts.json` vient du scan Java fait par `alpiq:create-postman`.

### 4. Construire la release

```bash
mvn alpiq:build-release -DreleaseVersion=26.06.01
```

Le plugin applique automatiquement :

```text
BOTH puis B2B
BOTH puis B2C
```

---

## Règles de génération

### Postman Struct

Pour B2B :

```text
BOTH/postman-struct
+
B2B/postman-struct
```

Résultat :

```text
target/releases/26.06.01/B2B/postman-struct/alpiq-postman-struct.json
```

Pour B2C :

```text
BOTH/postman-struct
+
B2C/postman-struct
```

Résultat :

```text
target/releases/26.06.01/B2C/postman-struct/alpiq-postman-struct.json
```

### Postman Jobs

Même logique :

```text
BOTH/postman-jobs + B2B/postman-jobs -> B2B/postman-jobs/alpiq-postman-jobs.json
BOTH/postman-jobs + B2C/postman-jobs -> B2C/postman-jobs/alpiq-postman-jobs.json
```

### Alpiq Scripts

Le fichier généré par le scan Java est copié dans chaque package :

```text
B2B/alpiq-scripts/alpiq-scripts.json
B2C/alpiq-scripts/alpiq-scripts.json
```

Source par défaut :

```text
target/generated-postman/alpiq-scripts/alpiq-scripts.json
```

### SQL Struct

Les fichiers SQL sont regroupés dans un seul fichier, en gardant le nom du fichier source dans un commentaire.

Pour B2B :

```text
BOTH/sql-struct
+
B2B/sql-struct
```

Résultat :

```text
B2B/sql-struct/alpiq-struct.sql
```

Exemple généré :

```sql
/*************************************************************************
 * File : BOTH/sql-struct/001_create_customer.sql
 *************************************************************************/

CREATE TABLE CUSTOMER (...);

/*************************************************************************
 * File : B2B/sql-struct/010_add_b2b_column.sql
 *************************************************************************/

ALTER TABLE CUSTOMER ADD PARTNER_CODE VARCHAR(50);
```

### SQL Data

Même logique :

```text
BOTH/sql-data + B2B/sql-data -> B2B/sql-data/alpiq-data.sql
BOTH/sql-data + B2C/sql-data -> B2C/sql-data/alpiq-data.sql
```

---

## Résultat final

```text
target/releases/
└── 26.06.01/
    ├── B2B/
    │   ├── postman-struct/
    │   │   └── alpiq-postman-struct.json
    │   ├── postman-jobs/
    │   │   └── alpiq-postman-jobs.json
    │   ├── alpiq-scripts/
    │   │   └── alpiq-scripts.json
    │   ├── sql-struct/
    │   │   └── alpiq-struct.sql
    │   └── sql-data/
    │       └── alpiq-data.sql
    │
    └── B2C/
        ├── postman-struct/
        │   └── alpiq-postman-struct.json
        ├── postman-jobs/
        │   └── alpiq-postman-jobs.json
        ├── alpiq-scripts/
        │   └── alpiq-scripts.json
        ├── sql-struct/
        │   └── alpiq-struct.sql
        └── sql-data/
            └── alpiq-data.sql
```

---

## Résumé affiché à la fin

Le plugin affiche un résumé de génération :

```text
=========================================================
        ALPIQ RELEASE PACKAGE
=========================================================

Release Version : 26.06.01

---------------------------------------------------------
Building B2B
---------------------------------------------------------
OK Merge BOTH/postman-struct : 4 collections
OK Merge B2B/postman-struct  : 2 collections
OK Generated                 : postman-struct/alpiq-postman-struct.json

OK Merge BOTH/postman-jobs   : 1 collections
OK Merge B2B/postman-jobs    : 2 collections
OK Generated                 : postman-jobs/alpiq-postman-jobs.json

OK Copied generated scripts  : alpiq-scripts/alpiq-scripts.json

OK Merge SQL Structure       : 8 files
OK Generated                 : sql-struct/alpiq-struct.sql

OK Merge SQL Data            : 15 files
OK Generated                 : sql-data/alpiq-data.sql

---------------------------------------------------------
Building B2C
---------------------------------------------------------
OK Merge BOTH/postman-struct : 4 collections
OK Merge B2C/postman-struct  : 1 collections
OK Generated                 : postman-struct/alpiq-postman-struct.json

OK Merge BOTH/postman-jobs   : 1 collections
OK Merge B2C/postman-jobs    : 1 collections
OK Generated                 : postman-jobs/alpiq-postman-jobs.json

OK Copied generated scripts  : alpiq-scripts/alpiq-scripts.json

OK Merge SQL Structure       : 7 files
OK Generated                 : sql-struct/alpiq-struct.sql

OK Merge SQL Data            : 12 files
OK Generated                 : sql-data/alpiq-data.sql

=========================================================
Release successfully generated
Output: target/releases/26.06.01
Packages generated: [B2B, B2C]
Elapsed time : 4.8 s
=========================================================
```

---

## Configuration dans le POM utilisateur

Après installation du plugin dans ton dépôt Maven local ou Nexus :

```xml
<plugin>
    <groupId>com.alpiq.maven.plugins</groupId>
    <artifactId>alpiq-release-maven-plugin</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <configuration>
        <releaseNotesDir>${project.basedir}/release-notes</releaseNotesDir>
        <outputDirectory>${project.build.directory}/releases</outputDirectory>
        <generatedScriptsFile>${project.build.directory}/generated-postman/alpiq-scripts/alpiq-scripts.json</generatedScriptsFile>
    </configuration>
</plugin>
```

---

## Paramètres principaux

| Paramètre | Goal | Défaut | Description |
|---|---|---|---|
| `inputDir` | `create-postman` | `${project.basedir}/src/main/java` | Dossier des sources Java à scanner |
| `postmanFilename` | `create-postman` | `${project.build.directory}/generated-postman/alpiq-scripts/alpiq-scripts.json` | Fichier Postman généré |
| `scriptsModulePath` | `create-postman` | `${project.basedir}` | Répertoire de travail Git, utile si les scripts Java sont dans un autre module |
| `modifiedLastDays` | `create-postman` | non renseigné | Filtre Git : fichiers Java modifiés dans les X derniers jours |
| `gitSinceTag` | `create-postman` | non renseigné | Filtre Git plus fiable : fichiers Java modifiés depuis un tag ou une référence |
| `gitSinceBranch` | `create-postman` | non renseigné | Filtre Git : fichiers Java modifiés depuis une branche ou une référence |
| `releaseVersion` | `build-release` | obligatoire | Version à lire dans `release-notes/<version>` |
| `releaseNotesDir` | `build-release` | `${project.basedir}/release-notes` | Racine des release notes |
| `outputDirectory` | `build-release` | `${project.build.directory}/releases` | Dossier de sortie |
| `generatedScriptsFile` | `build-release` | `${project.build.directory}/generated-postman/alpiq-scripts/alpiq-scripts.json` | Collection générée par scan Java |
| `modifiedLastDays` | `deploy-scripts` | `0` | Conservé pour le futur déploiement REST des scripts modifiés |

---

## Filtrage Git dans `create-postman`

Le contrôle `modifiedLastDays` est maintenant directement dans le goal `create-postman`.

Exemple :

```bash
mvn alpiq:create-postman -DmodifiedLastDays=7
```

Le plugin :

1. détecte la racine du repository Git depuis `scriptsModulePath` ;
2. récupère les fichiers modifiés via Git ;
3. filtre uniquement les fichiers `.java` ;
4. garde uniquement les fichiers situés sous `inputDir` ;
5. génère `alpiq-scripts.json` uniquement avec ces classes.

Cette approche est volontaire : elle évite `File.lastModified()`, qui n'est pas fiable après un `git clone`, un `git checkout` ou une exécution Jenkins.

Commandes Git utilisées :

```bash
# Avec modifiedLastDays
git log --since="7 days ago" --name-only --pretty=format: --

# Avec gitSinceTag
git diff --name-only 26.05.00...HEAD --

# Avec gitSinceBranch
git diff --name-only release/26.06...HEAD --
```

---

## Évolutions possibles

- Validation stricte de la numérotation `001_`, `002_`, etc.
- Validation JSON des collections Postman.
- Génération d'un ZIP final par environnement.
- Déploiement REST réel des scripts via `deploy-scripts`.
- Exclusion ou inclusion de fichiers par pattern.
