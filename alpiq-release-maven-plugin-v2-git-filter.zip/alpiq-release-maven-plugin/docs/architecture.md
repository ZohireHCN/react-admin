# Architecture

- `mojo/` : goals Maven.
- `service/` : logique métier de fusion Postman, fusion SQL et validation.
- `model/` : modèles de résumé.
- `util/` : utilitaires fichiers.
