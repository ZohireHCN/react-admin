# Workflow

1. `mvn clean install`
2. `mvn alpiq:create-postman`
3. Préparer `release-notes/<version>/BOTH`, `B2B`, `B2C`
4. `mvn alpiq:build-release -DreleaseVersion=<version>`
