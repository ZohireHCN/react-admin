# Alpiq Maven Plugin

Plugin Maven Alpiq pour générer des collections Postman depuis les scripts Java et pour assembler une release B2B/B2C depuis un dossier `release-notes`.

## Goal principal

```bash
mvn alpiq:create-postman
```

Deux modes existent :

1. Sans `releaseVersion` : génération Postman classique depuis les classes Java.
2. Avec `releaseVersion` : assemblage d'une release complète depuis le dossier de version.

---

## Structure de release attendue

La commande est lancée depuis le module `release-notes`.

```text
release-notes/
└── 26.06.01/
    ├── BOTH/
    │   ├── postman-struct/
    │   ├── postman-jobs/
    │   ├── sql-struct/
    │   └── sql-data/
    ├── B2B/
    │   ├── postman-struct/
    │   ├── postman-jobs/
    │   ├── sql-struct/
    │   └── sql-data/
    └── B2C/
        ├── postman-struct/
        ├── postman-jobs/
        ├── sql-struct/
        └── sql-data/
```

`BOTH` contient les éléments communs. `B2B` et `B2C` contiennent les éléments spécifiques.

L'ordre appliqué est toujours :

```text
BOTH puis B2B
BOTH puis B2C
```

Il n'y a pas de paramètre pour B2B/B2C : ce sont des conventions fixes du plugin.

---

## Commande release

Depuis `release-notes` :

```bash
mvn alpiq:create-postman -DreleaseVersion=26.06.01
```

Avec un filtre sur les fichiers modifiés :

```bash
mvn alpiq:create-postman \
  -DreleaseVersion=26.06.01 \
  -DmodifiedLastDays=7
```

Si le POM du plugin est dans un module différent du dossier de release :

```bash
mvn alpiq:create-postman \
  -DreleaseVersion=26.06.01 \
  -DreleaseModulePath=../release-notes \
  -DreleaseRootDir=.
```

---

## Résultat généré

```text
target/release/
└── 26.06.01/
    ├── release.json
    ├── B2B/
    │   ├── postman-struct/
    │   │   └── alpiq-postman-struct.json
    │   ├── postman-jobs/
    │   │   └── alpiq-postman-jobs.json
    │   ├── sql-struct/
    │   │   └── alpiq-sql-struct.sql
    │   └── sql-data/
    │       └── alpiq-sql-data.sql
    └── B2C/
        ├── postman-struct/
        │   └── alpiq-postman-struct.json
        ├── postman-jobs/
        │   └── alpiq-postman-jobs.json
        ├── sql-struct/
        │   └── alpiq-sql-struct.sql
        └── sql-data/
            └── alpiq-sql-data.sql
```

---

## Règles Postman

Pour chaque environnement, le plugin fusionne les collections JSON en une seule collection par dossier :

```text
BOTH/postman-struct + B2B/postman-struct -> B2B/postman-struct/alpiq-postman-struct.json
BOTH/postman-jobs   + B2B/postman-jobs   -> B2B/postman-jobs/alpiq-postman-jobs.json
```

Même logique pour B2C.

Les fichiers sont triés par nom de chemin. Il est recommandé d'utiliser une numérotation :

```text
001_create_custom_table.postman_collection.json
002_create_columns.postman_collection.json
003_create_indexes.postman_collection.json
```

---

## Règles SQL

Le SQL est aussi regroupé en un seul fichier par sous-dossier :

```text
BOTH/sql-struct + B2B/sql-struct -> B2B/sql-struct/alpiq-sql-struct.sql
BOTH/sql-data   + B2B/sql-data   -> B2B/sql-data/alpiq-sql-data.sql
```

Chaque script source est précédé d'un commentaire qui garde le nom du fichier original :

```sql
-- ============================================================
-- FILE: 001_create_table.sql
-- PATH: /.../release-notes/26.06.01/BOTH/sql-struct/001_create_table.sql
-- ============================================================
CREATE TABLE ...;
```

Cela permet d'avoir un seul fichier SQL à exécuter tout en gardant la traçabilité des scripts d'origine.

---

## Résumé affiché à la fin

Exemple :

```text
=== Alpiq Release 26.06.01 ===

Building B2B
  ✓ postman-struct -> alpiq-postman-struct.json (5 collection(s) source)
  ✓ postman-jobs   -> alpiq-postman-jobs.json (2 collection(s) source)
  ✓ sql-struct     -> alpiq-sql-struct.sql (8 script(s) source)
  ✓ sql-data       -> alpiq-sql-data.sql (15 script(s) source)
  Ordre appliqué: BOTH puis B2B

Building B2C
  ✓ postman-struct -> alpiq-postman-struct.json (5 collection(s) source)
  ✓ postman-jobs   -> alpiq-postman-jobs.json (1 collection(s) source)
  ✓ sql-struct     -> alpiq-sql-struct.sql (8 script(s) source)
  ✓ sql-data       -> alpiq-sql-data.sql (12 script(s) source)
  Ordre appliqué: BOTH puis B2C

Release generated successfully.
```

---

## Paramètres utiles

| Paramètre | Défaut | Description |
|---|---:|---|
| `releaseVersion` | vide | Version à assembler, par exemple `26.06.01` |
| `releaseModulePath` | vide | Chemin du module contenant `release-notes` |
| `releaseRootDir` | `.` | Racine où se trouve le dossier de version |
| `releaseOutputDir` | `${project.build.directory}/release` | Dossier de sortie |
| `modifiedLastDays` | `0` | `0` = tous les fichiers, sinon seulement les fichiers modifiés depuis X jours |

