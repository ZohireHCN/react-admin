package com.alpiqsoft.dto;

public class ScriptInstance {
    private String code;
    private String description;
    private String type = "JAVA";
    private String script;

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getScript() { return script; }
    public void setScript(String script) { this.script = script; }
}
