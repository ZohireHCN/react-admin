package com.alpiqsoft.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ScriptSourceParser {
    private static final Pattern PACKAGE = Pattern.compile("(?m)^\\s*package\\s+([a-zA-Z_][\\w.]*)\\s*;");
    private static final Pattern TYPE = Pattern.compile("(?m)^\\s*public\\s+(?:abstract\\s+|final\\s+)?(?:class|interface|enum)\\s+([A-Za-z_][\\w]*)");

    private ScriptSourceParser() {}

    public static String packageName(String source) { return find(PACKAGE, source); }
    public static String simpleClassName(String source) { return find(TYPE, source); }

    public static String fullClassName(String source) {
        String simple = simpleClassName(source);
        if (simple == null) return null;
        String pkg = packageName(source);
        return pkg == null || pkg.isEmpty() ? simple : pkg + "." + simple;
    }

    private static String find(Pattern pattern, String source) {
        Matcher matcher = pattern.matcher(source == null ? "" : source);
        return matcher.find() ? matcher.group(1).trim() : null;
    }
}
