package com.alpiqsoft.utils;

import org.apache.commons.io.FileUtils;
import org.apache.maven.plugin.MojoExecutionException;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public final class FileScanner {
    private FileScanner() {}

    /**
     * Retourne les fichiers Java à traiter.
     *
     * @param inputDir chemin du dossier scripts, relatif au module courant ou absolu
     * @param javaFile fichier Java unique, relatif au module courant ou absolu
     * @param scriptsModulePath chemin/URL file: du module qui contient les scripts, utile si le plugin est exécuté depuis un autre module
     * @param modifiedLastDays filtre optionnel: ne garde que les fichiers modifiés depuis X jours. 0 ou négatif = pas de filtre
     */
    public static List<File> javaFiles(String inputDir, String javaFile, String scriptsModulePath, int modifiedLastDays) throws MojoExecutionException {
        List<File> files = new ArrayList<File>();
        File baseDir = resolveBaseDir(scriptsModulePath);

        if (javaFile != null && !javaFile.trim().isEmpty()) {
            File file = resolveFile(baseDir, javaFile);
            if (!file.isFile()) throw new MojoExecutionException("javaFile introuvable: " + file.getAbsolutePath());
            if (isModifiedInLastDays(file, modifiedLastDays)) files.add(file);
            return files;
        }

        if (inputDir == null || inputDir.trim().isEmpty()) {
            throw new MojoExecutionException("Paramètre requis: inputDir ou javaFile");
        }

        File dir = resolveFile(baseDir, inputDir);
        if (!dir.isDirectory()) throw new MojoExecutionException("inputDir introuvable: " + dir.getAbsolutePath());

        Collection<File> found = FileUtils.listFiles(dir, new String[]{"java"}, true);
        for (File file : found) {
            if (isModifiedInLastDays(file, modifiedLastDays)) files.add(file);
        }
        files.sort(Comparator.comparing(File::getAbsolutePath));
        return files;
    }

    public static List<File> javaFiles(String inputDir, String javaFile) throws MojoExecutionException {
        return javaFiles(inputDir, javaFile, null, 0);
    }

    private static File resolveBaseDir(String scriptsModulePath) throws MojoExecutionException {
        if (scriptsModulePath == null || scriptsModulePath.trim().isEmpty()) return null;
        try {
            String value = scriptsModulePath.trim();
            if (value.startsWith("file:")) return new File(new URI(value));
            return new File(value);
        } catch (Exception e) {
            throw new MojoExecutionException("scriptsModulePath invalide: " + scriptsModulePath, e);
        }
    }

    private static File resolveFile(File baseDir, String path) {
        File file = new File(path);
        if (file.isAbsolute() || baseDir == null) return file;
        return new File(baseDir, path);
    }

    private static boolean isModifiedInLastDays(File file, int modifiedLastDays) {
        if (modifiedLastDays <= 0) return true;
        long limit = System.currentTimeMillis() - (modifiedLastDays * 24L * 60L * 60L * 1000L);
        return file.lastModified() >= limit;
    }
}
