package com.alpiqsoft.utils;

import org.apache.commons.io.FileUtils;
import org.apache.maven.plugin.MojoExecutionException;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public final class ReleaseScanner {
    private ReleaseScanner() {}

    public static File resolveReleaseDir(String releaseModulePath, String releaseRootDir, String releaseVersion) throws MojoExecutionException {
        if (releaseVersion == null || releaseVersion.trim().isEmpty()) {
            throw new MojoExecutionException("Paramètre requis: releaseVersion");
        }
        File module = resolveBaseDir(releaseModulePath);
        String root = releaseRootDir == null || releaseRootDir.trim().isEmpty() ? "" : releaseRootDir.trim();
        File rootDir = resolveFile(module, root);
        File versionDir = new File(rootDir, releaseVersion.trim());
        if (!versionDir.isDirectory()) {
            throw new MojoExecutionException("Dossier release introuvable: " + versionDir.getAbsolutePath());
        }
        return versionDir;
    }

    public static List<File> releaseFiles(File releaseDir, int modifiedLastDays) {
        List<File> files = new ArrayList<File>();
        Collection<File> found = FileUtils.listFiles(releaseDir, new String[]{"json", "sql", "java", "groovy", "xml", "yaml", "yml"}, true);
        for (File file : found) {
            if (isModifiedInLastDays(file, modifiedLastDays)) files.add(file);
        }
        files.sort(Comparator.comparing(File::getAbsolutePath));
        return files;
    }


    public static List<File> filesByExtension(File dir, int modifiedLastDays, String extension) {
        List<File> files = new ArrayList<File>();
        if (dir == null || !dir.isDirectory()) return files;
        Collection<File> found = FileUtils.listFiles(dir, new String[]{extension}, true);
        for (File file : found) {
            if (isModifiedInLastDays(file, modifiedLastDays)) files.add(file);
        }
        files.sort(Comparator.comparing(File::getAbsolutePath));
        return files;
    }

    public static boolean isPostmanCollection(File file) {
        return file != null && file.getName().toLowerCase().endsWith(".json");
    }

    public static boolean isSql(File file) {
        return file != null && file.getName().toLowerCase().endsWith(".sql");
    }

    public static boolean isJava(File file) {
        return file != null && file.getName().toLowerCase().endsWith(".java");
    }

    public static boolean isGroovy(File file) {
        return file != null && file.getName().toLowerCase().endsWith(".groovy");
    }

    public static String relativePath(File root, File file) {
        return root.toURI().relativize(file.toURI()).getPath();
    }

    private static File resolveBaseDir(String path) throws MojoExecutionException {
        if (path == null || path.trim().isEmpty()) return null;
        try {
            String value = path.trim();
            if (value.startsWith("file:")) return new File(new URI(value));
            return new File(value);
        } catch (Exception e) {
            throw new MojoExecutionException("releaseModulePath invalide: " + path, e);
        }
    }

    private static File resolveFile(File baseDir, String path) {
        if (path == null || path.trim().isEmpty()) return baseDir == null ? new File(".") : baseDir;
        File file = new File(path);
        if (file.isAbsolute() || baseDir == null) return file;
        return new File(baseDir, path);
    }

    public static boolean isModifiedInLastDays(File file, int modifiedLastDays) {
        if (modifiedLastDays <= 0) return true;
        long limit = System.currentTimeMillis() - (modifiedLastDays * 24L * 60L * 60L * 1000L);
        return file.lastModified() >= limit;
    }
}
