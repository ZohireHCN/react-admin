package com.alpiqsoft.utils;

public final class XmlUtil {
    private XmlUtil() {}
    public static String attr(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
    }
    public static String cdata(String value) {
        if (value == null) return "";
        return value.replace("]]>", "]]]]><![CDATA[>");
    }
}
