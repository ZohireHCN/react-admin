package com.alpiqsoft.plugin;

import com.alpiqsoft.utils.FileScanner;
import com.alpiqsoft.utils.ScriptSourceParser;
import com.alpiqsoft.utils.XmlUtil;
import org.apache.commons.io.FileUtils;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import java.io.File;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@Mojo(name = "deploy-scripts")
public class RestPlugin extends AbstractMojo {
    @Parameter(property = "endpoint", required = true)
    private URI endpoint;

    @Parameter(property = "resource", defaultValue = "scriptInstance/createOrUpdate")
    private String resource;

    @Parameter(property = "inputDir", defaultValue = "")
    private String inputDir;

    @Parameter(property = "javaFile")
    private String javaFile;

    /** Chemin du module qui contient les scripts. Accepte un chemin local ou une URL file:. */
    @Parameter(property = "scriptsModulePath", defaultValue = "")
    private String scriptsModulePath;

    /** Filtre les scripts modifiés depuis X jours. 0 = tous les scripts. */
    @Parameter(property = "modifiedLastDays", defaultValue = "0")
    private int modifiedLastDays;

    @Parameter(property = "method", defaultValue = "POST")
    private String method;

    @Parameter(property = "headers")
    private Map<String, String> headers;

    @Parameter(property = "queryParams")
    private Map<String, String> queryParams;

    @Parameter(property = "saveResponse", defaultValue = "false")
    private boolean saveResponse;

    @Parameter(property = "outputDir", defaultValue = "${project.build.directory}/rest")
    private File outputDir;

    public void execute() throws MojoExecutionException {
        List<File> files = FileScanner.javaFiles(inputDir, javaFile, scriptsModulePath, modifiedLastDays);
        String baseUrl = buildUrl();
        if (saveResponse) outputDir.mkdirs();
        int ok = 0;
        for (File file : files) {
            String payload = toScriptInstanceXml(file);
            String response = send(baseUrl, payload);
            if (saveResponse) save(file, payload, response);
            ok++;
        }
        getLog().info("Déploiement terminé: " + ok + " script(s) envoyé(s) vers " + baseUrl);
    }

    private String toScriptInstanceXml(File file) throws MojoExecutionException {
        try {
            String source = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
            String fullName = ScriptSourceParser.fullClassName(source);
            if (fullName == null) throw new MojoExecutionException("Classe publique non trouvée: " + file.getAbsolutePath());
            String simpleName = fullName.substring(fullName.lastIndexOf('.') + 1);
            return "<ScriptInstance code=\"" + XmlUtil.attr(fullName) + "\" description=\"" + XmlUtil.attr(simpleName) + "\">\n" +
                    "  <type>JAVA</type>\n" +
                    "  <reuse>true</reuse>\n" +
                    "  <script><![CDATA[" + XmlUtil.cdata(source) + "]]></script>\n" +
                    "</ScriptInstance>";
        } catch (Exception e) {
            if (e instanceof MojoExecutionException) throw (MojoExecutionException) e;
            throw new MojoExecutionException("Erreur lecture script: " + file.getAbsolutePath(), e);
        }
    }

    private String send(String url, String payload) throws MojoExecutionException {
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod(method == null ? "POST" : method.toUpperCase());
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/xml; charset=UTF-8");
            con.setRequestProperty("Accept", "application/xml, application/json, */*");
            if (headers != null) {
                for (Map.Entry<String, String> h : headers.entrySet()) con.setRequestProperty(h.getKey(), h.getValue());
            }
            try (OutputStream os = con.getOutputStream()) {
                os.write(payload.getBytes(StandardCharsets.UTF_8));
            }
            int status = con.getResponseCode();
            String response = "";
            if (con.getErrorStream() != null) response = org.apache.commons.io.IOUtils.toString(con.getErrorStream(), StandardCharsets.UTF_8);
            else if (con.getInputStream() != null) response = org.apache.commons.io.IOUtils.toString(con.getInputStream(), StandardCharsets.UTF_8);
            if (status < 200 || status >= 300) throw new MojoExecutionException("Erreur HTTP " + status + ": " + response);
            return response;
        } catch (Exception e) {
            if (e instanceof MojoExecutionException) throw (MojoExecutionException) e;
            throw new MojoExecutionException("Erreur appel REST vers " + url, e);
        }
    }

    private String buildUrl() {
        String url = endpoint.toString();
        if (resource != null && !resource.trim().isEmpty()) {
            if (!url.endsWith("/")) url += "/";
            url += resource.startsWith("/") ? resource.substring(1) : resource;
        }
        if (queryParams != null && !queryParams.isEmpty()) {
            String sep = url.contains("?") ? "&" : "?";
            StringBuilder sb = new StringBuilder(url);
            for (Map.Entry<String, String> e : queryParams.entrySet()) {
                sb.append(sep).append(e.getKey()).append("=").append(e.getValue());
                sep = "&";
            }
            url = sb.toString();
        }
        return url;
    }

    private void save(File script, String request, String response) throws MojoExecutionException {
        try {
            String base = script.getName().replaceAll("\\.java$", "");
            FileUtils.writeStringToFile(new File(outputDir, base + "-request.xml"), request, StandardCharsets.UTF_8);
            FileUtils.writeStringToFile(new File(outputDir, base + "-response.txt"), response, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new MojoExecutionException("Impossible de sauvegarder request/response", e);
        }
    }
}
