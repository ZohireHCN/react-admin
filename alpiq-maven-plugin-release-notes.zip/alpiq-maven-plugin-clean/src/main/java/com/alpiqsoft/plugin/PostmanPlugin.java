package com.alpiqsoft.plugin;

import com.alpiqsoft.utils.FileScanner;
import com.alpiqsoft.utils.ScriptSourceParser;
import com.alpiqsoft.utils.ReleaseScanner;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

@Mojo(name = "create-postman", aggregator = true)
public class PostmanPlugin extends AbstractMojo {
    private static final List<String> TARGET_ENVS = Arrays.asList("B2B", "B2C");
    private static final List<String> SOURCE_ORDER_PREFIXES = Arrays.asList("BOTH");
    private static final List<String> RELEASE_FOLDERS = Arrays.asList("postman-struct", "postman-jobs", "sql-struct", "sql-data");

    @Parameter(property = "inputDir")
    private String inputDir;

    @Parameter(property = "javaFile")
    private String javaFile;

    /** Chemin du module qui contient les scripts. Accepte un chemin local ou une URL file:. */
    @Parameter(property = "scriptsModulePath", defaultValue = "")
    private String scriptsModulePath;

    /** Filtre les fichiers modifiés depuis X jours. 0 = tous les fichiers. */
    @Parameter(property = "modifiedLastDays", defaultValue = "0")
    private int modifiedLastDays;

    @Parameter(property = "postmanFilename", defaultValue = "${project.build.directory}/postman/postman.json")
    private String postmanFilename;

    /** Version release à générer. Exemple: 26.06.01. Si renseigné, le goal assemble la release complète. */
    @Parameter(property = "releaseVersion", defaultValue = "")
    private String releaseVersion;

    /** Module qui contient le dossier release-notes. Vide = dossier courant Maven. */
    @Parameter(property = "releaseModulePath", defaultValue = "")
    private String releaseModulePath;

    /** Dossier racine qui contient le dossier de version. Pour release-notes/26.06.01 lancé depuis release-notes: . */
    @Parameter(property = "releaseRootDir", defaultValue = ".")
    private String releaseRootDir;

    /** Dossier de sortie pour une release complète. */
    @Parameter(property = "releaseOutputDir", defaultValue = "${project.build.directory}/release")
    private File releaseOutputDir;

    public void execute() throws MojoExecutionException {
        if (releaseVersion != null && !releaseVersion.trim().isEmpty()) {
            generateReleaseFolder();
            return;
        }
        generateScriptPostmanFromJavaFiles();
    }

    private void generateScriptPostmanFromJavaFiles() throws MojoExecutionException {
        File output = new File(postmanFilename);
        File parent = output.getParentFile();
        if (parent != null) parent.mkdirs();

        String template = readTemplate();
        int start = template.indexOf("\"---startScript---\"");
        int end = template.indexOf("\"---endScript---\"");
        if (start < 0 || end < 0 || end <= start) throw new MojoExecutionException("Template Postman invalide");

        String header = template.substring(0, start);
        String itemTemplate = template.substring(start + "\"---startScript---\"".length(), end);
        String footer = template.substring(end + "\"---endScript---\"".length());

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(output, false))) {
            writer.write(header);
            List<File> files = FileScanner.javaFiles(inputDir, javaFile, scriptsModulePath, modifiedLastDays);
            int count = 0;
            for (File file : files) {
                String source = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
                String fullName = ScriptSourceParser.fullClassName(source);
                if (fullName == null) {
                    getLog().warn("Ignoré, classe publique non trouvée: " + file.getAbsolutePath());
                    continue;
                }
                String simpleName = fullName.substring(fullName.lastIndexOf('.') + 1);
                String item = itemTemplate
                        .replace("<---scriptClassName--->", fullName)
                        .replace("<---simpleScriptClassName--->", simpleName)
                        .replace("<---scriptContent--->", StringEscapeUtils.escapeJson(source).replaceAll("(\\r\\n|\\r|\\n)+", "\\\\n"));
                if (count > 0) writer.write(',');
                writer.write(item);
                count++;
            }
            writer.write(System.lineSeparator());
            writer.write(footer);
            getLog().info("Collection Postman générée: " + output.getAbsolutePath() + " (" + count + " scripts)");
        } catch (Exception e) {
            throw new MojoExecutionException("Erreur génération Postman", e);
        }
    }

    private void generateReleaseFolder() throws MojoExecutionException {
        try {
            File releaseDir = ReleaseScanner.resolveReleaseDir(releaseModulePath, releaseRootDir, releaseVersion);
            File outputVersionDir = new File(releaseOutputDir, releaseVersion.trim());
            if (outputVersionDir.exists()) FileUtils.deleteDirectory(outputVersionDir);
            outputVersionDir.mkdirs();

            List<EnvSummary> summaries = new ArrayList<EnvSummary>();
            for (String env : TARGET_ENVS) {
                EnvSummary summary = buildEnvironment(releaseDir, outputVersionDir, env);
                summaries.add(summary);
            }

            File releaseJson = new File(outputVersionDir, "release.json");
            FileUtils.writeStringToFile(releaseJson, buildReleaseJson(releaseDir, summaries), StandardCharsets.UTF_8);

            logSummary(outputVersionDir, summaries);
        } catch (Exception e) {
            if (e instanceof MojoExecutionException) throw (MojoExecutionException) e;
            throw new MojoExecutionException("Erreur génération dossier release", e);
        }
    }

    private EnvSummary buildEnvironment(File releaseDir, File outputVersionDir, String env) throws Exception {
        File envDir = new File(releaseDir, env);
        if (!envDir.isDirectory()) {
            throw new MojoExecutionException("Dossier obligatoire introuvable: " + envDir.getAbsolutePath());
        }

        File outputEnvDir = new File(outputVersionDir, env);
        outputEnvDir.mkdirs();

        EnvSummary summary = new EnvSummary(env);
        for (String folder : RELEASE_FOLDERS) {
            List<File> sourceDirs = new ArrayList<File>();
            for (String prefix : SOURCE_ORDER_PREFIXES) {
                File commonDir = new File(new File(releaseDir, prefix), folder);
                if (commonDir.isDirectory()) sourceDirs.add(commonDir);
            }
            File specificDir = new File(envDir, folder);
            if (!specificDir.isDirectory()) {
                throw new MojoExecutionException("Dossier obligatoire introuvable: " + specificDir.getAbsolutePath());
            }
            sourceDirs.add(specificDir);

            File outputFolder = new File(outputEnvDir, folder);
            outputFolder.mkdirs();

            if (folder.startsWith("postman-")) {
                String outputName = "alpiq-" + folder + ".json";
                PostmanMergeResult result = mergePostmanCollections(folder, sourceDirs, new File(outputFolder, outputName));
                summary.addPostman(folder, result);
            } else if (folder.startsWith("sql-")) {
                String outputName = "alpiq-" + folder + ".sql";
                SqlMergeResult result = mergeSqlFiles(folder, sourceDirs, new File(outputFolder, outputName));
                summary.addSql(folder, result);
            }
        }
        return summary;
    }

    private PostmanMergeResult mergePostmanCollections(String folderName, List<File> sourceDirs, File output) throws Exception {
        List<File> collections = new ArrayList<File>();
        for (File dir : sourceDirs) {
            collections.addAll(ReleaseScanner.filesByExtension(dir, modifiedLastDays, "json"));
        }

        StringBuilder items = new StringBuilder();
        int addedCollections = 0;
        int sourceFileCount = 0;
        for (File collection : collections) {
            String json = FileUtils.readFileToString(collection, StandardCharsets.UTF_8);
            String itemArray = extractJsonArray(json, "item");
            if (itemArray == null || itemArray.trim().isEmpty()) {
                getLog().warn("Collection Postman ignorée, tableau item introuvable: " + collection.getAbsolutePath());
                continue;
            }
            if (addedCollections > 0) items.append(",\n");
            items.append("    {\n");
            items.append("      \"name\": \"").append(escape(collection.getName())).append("\",\n");
            items.append("      \"item\": [").append(itemArray).append("]\n");
            items.append("    }");
            addedCollections++;
            sourceFileCount++;
        }

        String collectionName = "Alpiq " + folderName + " " + releaseVersion.trim();
        String merged = "{\n" +
                "  \"info\": {\n" +
                "    \"name\": \"" + escape(collectionName) + "\",\n" +
                "    \"schema\": \"https://schema.getpostman.com/json/collection/v2.1.0/collection.json\"\n" +
                "  },\n" +
                "  \"item\": [\n" + items + "\n  ]\n" +
                "}\n";
        FileUtils.writeStringToFile(output, merged, StandardCharsets.UTF_8);
        return new PostmanMergeResult(output.getName(), sourceFileCount, addedCollections);
    }

    private SqlMergeResult mergeSqlFiles(String folderName, List<File> sourceDirs, File output) throws Exception {
        List<File> sqlFiles = new ArrayList<File>();
        for (File dir : sourceDirs) {
            sqlFiles.addAll(ReleaseScanner.filesByExtension(dir, modifiedLastDays, "sql"));
        }

        StringBuilder sql = new StringBuilder();
        sql.append("-- ============================================================\n");
        sql.append("-- Alpiq release ").append(releaseVersion.trim()).append(" / ").append(folderName).append("\n");
        sql.append("-- Generated by alpiq-maven-plugin\n");
        sql.append("-- ============================================================\n\n");

        for (File file : sqlFiles) {
            sql.append("-- ============================================================\n");
            sql.append("-- FILE: ").append(file.getName()).append("\n");
            sql.append("-- PATH: ").append(file.getAbsolutePath().replace('\\', '/')).append("\n");
            sql.append("-- ============================================================\n");
            sql.append(FileUtils.readFileToString(file, StandardCharsets.UTF_8));
            if (!sql.toString().endsWith("\n")) sql.append("\n");
            sql.append("\n");
        }

        FileUtils.writeStringToFile(output, sql.toString(), StandardCharsets.UTF_8);
        return new SqlMergeResult(output.getName(), sqlFiles.size());
    }

    private String extractJsonArray(String json, String propertyName) {
        String token = "\"" + propertyName + "\"";
        int p = json.indexOf(token);
        while (p >= 0) {
            int colon = json.indexOf(':', p + token.length());
            if (colon < 0) return null;
            int start = json.indexOf('[', colon + 1);
            if (start < 0) return null;
            int end = findMatchingBracket(json, start);
            if (end < 0) return null;
            return json.substring(start + 1, end).trim();
        }
        return null;
    }

    private int findMatchingBracket(String text, int start) {
        int depth = 0;
        boolean inString = false;
        boolean escaped = false;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (escaped) {
                    escaped = false;
                } else if (c == '\\') {
                    escaped = true;
                } else if (c == '"') {
                    inString = false;
                }
            } else {
                if (c == '"') {
                    inString = true;
                } else if (c == '[') {
                    depth++;
                } else if (c == ']') {
                    depth--;
                    if (depth == 0) return i;
                }
            }
        }
        return -1;
    }

    private void logSummary(File outputVersionDir, List<EnvSummary> summaries) {
        getLog().info("");
        getLog().info("=== Alpiq Release " + releaseVersion.trim() + " ===");
        getLog().info("Source: " + outputVersionDir.getAbsolutePath());
        if (modifiedLastDays > 0) {
            getLog().info("Filtre: fichiers modifiés dans les " + modifiedLastDays + " dernier(s) jour(s)");
        }
        for (EnvSummary summary : summaries) {
            getLog().info("");
            getLog().info("Building " + summary.env);
            getLog().info("  ✓ postman-struct -> " + summary.postmanStructOutput + " (" + summary.postmanStructFiles + " collection(s) source)");
            getLog().info("  ✓ postman-jobs   -> " + summary.postmanJobsOutput + " (" + summary.postmanJobsFiles + " collection(s) source)");
            getLog().info("  ✓ sql-struct     -> " + summary.sqlStructOutput + " (" + summary.sqlStructFiles + " script(s) source)");
            getLog().info("  ✓ sql-data       -> " + summary.sqlDataOutput + " (" + summary.sqlDataFiles + " script(s) source)");
            getLog().info("  Ordre appliqué: BOTH puis " + summary.env);
        }
        getLog().info("");
        getLog().info("Release generated successfully.");
    }

    private String buildReleaseJson(File releaseDir, List<EnvSummary> summaries) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"version\": \"").append(escape(releaseVersion.trim())).append("\",\n");
        sb.append("  \"sourceDir\": \"").append(escape(releaseDir.getAbsolutePath())).append("\",\n");
        sb.append("  \"order\": [\"BOTH\", \"B2B/B2C\"],\n");
        sb.append("  \"folders\": [\"postman-struct\", \"postman-jobs\", \"sql-struct\", \"sql-data\"],\n");
        sb.append("  \"modifiedLastDays\": ").append(modifiedLastDays).append(",\n");
        sb.append("  \"environments\": [\n");
        for (int i = 0; i < summaries.size(); i++) {
            EnvSummary s = summaries.get(i);
            if (i > 0) sb.append(",\n");
            sb.append("    {\n");
            sb.append("      \"name\": \"").append(escape(s.env)).append("\",\n");
            sb.append("      \"postmanStructFiles\": ").append(s.postmanStructFiles).append(",\n");
            sb.append("      \"postmanJobsFiles\": ").append(s.postmanJobsFiles).append(",\n");
            sb.append("      \"sqlStructFiles\": ").append(s.sqlStructFiles).append(",\n");
            sb.append("      \"sqlDataFiles\": ").append(s.sqlDataFiles).append("\n");
            sb.append("    }");
        }
        sb.append("\n  ]\n");
        sb.append("}\n");
        return sb.toString();
    }

    private String escape(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String readTemplate() throws MojoExecutionException {
        URL url = getClass().getClassLoader().getResource("Postman.collection.template.json");
        if (url == null) throw new MojoExecutionException("Postman.collection.template.json introuvable");
        try (Scanner scanner = new Scanner(url.openStream(), "UTF-8")) {
            scanner.useDelimiter("\\Z");
            return scanner.hasNext() ? scanner.next() : "";
        } catch (Exception e) {
            throw new MojoExecutionException("Impossible de lire le template Postman", e);
        }
    }

    private static final class EnvSummary {
        private final String env;
        private int postmanStructFiles;
        private int postmanJobsFiles;
        private int sqlStructFiles;
        private int sqlDataFiles;
        private String postmanStructOutput;
        private String postmanJobsOutput;
        private String sqlStructOutput;
        private String sqlDataOutput;

        private EnvSummary(String env) {
            this.env = env;
        }

        private void addPostman(String folder, PostmanMergeResult result) {
            if ("postman-struct".equals(folder)) {
                postmanStructFiles = result.sourceFiles;
                postmanStructOutput = result.outputFile;
            } else if ("postman-jobs".equals(folder)) {
                postmanJobsFiles = result.sourceFiles;
                postmanJobsOutput = result.outputFile;
            }
        }

        private void addSql(String folder, SqlMergeResult result) {
            if ("sql-struct".equals(folder)) {
                sqlStructFiles = result.sourceFiles;
                sqlStructOutput = result.outputFile;
            } else if ("sql-data".equals(folder)) {
                sqlDataFiles = result.sourceFiles;
                sqlDataOutput = result.outputFile;
            }
        }
    }

    private static final class PostmanMergeResult {
        private final String outputFile;
        private final int sourceFiles;
        private final int sourceCollections;

        private PostmanMergeResult(String outputFile, int sourceFiles, int sourceCollections) {
            this.outputFile = outputFile;
            this.sourceFiles = sourceFiles;
            this.sourceCollections = sourceCollections;
        }
    }

    private static final class SqlMergeResult {
        private final String outputFile;
        private final int sourceFiles;

        private SqlMergeResult(String outputFile, int sourceFiles) {
            this.outputFile = outputFile;
            this.sourceFiles = sourceFiles;
        }
    }
}
